package naogateway.value

case class Nao(title: String, host: String, port: Int)
